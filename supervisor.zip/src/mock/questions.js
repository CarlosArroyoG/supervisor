export const questions = [
  {
    id: 1,
    text: "¿El área de ventas está limpia y libre de polvo?",
    category: "sucursal"
  },
  {
    id: 2,
    text: "¿Los productos están organizados según el planograma?",
    category: "sucursal"
  },
  {
    id: 3,
    text: "¿Hay faltantes visibles en el inventario?",
    category: "sucursal"
  },
  {
    id: 4,
    text: "¿Los empleados siguen el proceso de venta paso a paso?",
    category: "empleados"
  },
  {
    id: 5,
    text: "¿El uniforme de los empleados está completo y limpio?",
    category: "empleados"
  },
  {
    id: 6,
    text: "¿Los empleados mantienen una apariencia personal adecuada?",
    category: "empleados"
  }
];